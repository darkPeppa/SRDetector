# O2 - scintillator x coating x wall glass (full grid, L = 2 mm, 60 keV)

All 32 combinations of four scintillators, four coatings and two wall glasses on the full detector with 2 mm channels. Objective: light in the full-energy peak (pe/keV x photopeak fraction), i.e. spectroscopic quality. The Pareto front trades light against speed (median photon arrival time).

* Base configuration: `full.yaml`, fixed: `{'beam.energy': '60 keV', 'geometry.length': '2 mm'}`
* Objective: `det_yield_per_keV * photopeak_fraction` (maximise)
* Constraints: `em_crosstalk <= 0.3`
* Search: `{'sampler': 'grid', 'events': [400, 1600], 'eta': 4, 'final': {'top': 3, 'events': 4000, 'repeats': 3}, 'seed': 2}`
* Simulations: 49, feasible: 46 / 49

## Best configuration

Validated with independent seeds (mean ± std):

* **core** = CsI_Tl
* **coat** = Ag
* **wall** = LeadGlass_MCP
* objective = 7.333 ± 0.067
* det_yield_per_keV = 8.246 ± 0.023
* photopeak_fraction = 0.8893 ± 0.0056
* k_escape_fraction = 0.09058 ± 0.0059
* t_det_median_ns = 836.5 ± 5.7
* em_crosstalk = 0.1666 ± 0.0052

Ready-to-run configuration: [`best.yaml`](best.yaml) (`srdet run runs/optimize/20261024-205807_O02_materials_grid/best.yaml`)

## Validated candidates

| core   | coat   | wall          |   objective |   objective_std |   det_yield_per_keV |   photopeak_fraction |   k_escape_fraction |   t_det_median_ns |   em_crosstalk |
|:-------|:-------|:--------------|------------:|----------------:|--------------------:|---------------------:|--------------------:|------------------:|---------------:|
| CsI_Tl | Ag     | LeadGlass_MCP |       7.333 |         0.06688 |               8.246 |               0.8893 |             0.09058 |            836.5  |         0.1666 |
| CsI_Tl | Ag     | Borosilicate  |       6.471 |         0.05224 |               8.219 |               0.7873 |             0.1091  |            835.6  |         0.1962 |
| GAGG   | Ag     | LeadGlass_MCP |       5.795 |         0.05412 |               6.861 |               0.8447 |             0.1353  |             62.35 |         0.2563 |

## Top of the last screening stage

|   trial | stage   |   events | core   | coat    | wall          |   objective | feasible   |   det_yield_per_keV |   photopeak_fraction |   k_escape_fraction |   t_det_median_ns |   em_crosstalk |
|--------:|:--------|---------:|:-------|:--------|:--------------|------------:|:-----------|--------------------:|---------------------:|--------------------:|------------------:|---------------:|
|      32 | s1      |     1600 | CsI_Tl | Ag      | LeadGlass_MCP |       7.314 | True       |               8.178 |               0.8944 |             0.08423 |            834.8  |        0.1562  |
|      33 | s1      |     1600 | CsI_Tl | Ag      | Borosilicate  |       6.461 | True       |               8.31  |               0.7775 |             0.1106  |            845.4  |        0.1836  |
|      34 | s1      |     1600 | GAGG   | Ag      | LeadGlass_MCP |       5.864 | True       |               6.823 |               0.8594 |             0.1197  |             63.51 |        0.2474  |
|      35 | s1      |     1600 | GAGG   | Ag      | Borosilicate  |       5.252 | True       |               6.905 |               0.7606 |             0.1536  |             63.32 |        0.2818  |
|      36 | s1      |     1600 | CsI_Tl | ESR_LUT | LeadGlass_MCP |       3.545 | True       |               4.162 |               0.8519 |             0.1008  |            847.4  |        0.2055  |
|      37 | s1      |     1600 | LYSO   | Ag      | LeadGlass_MCP |       3.095 | True       |               3.288 |               0.9413 |             0.00304 |             27.64 |        0.09667 |
|      38 | s1      |     1600 | CsI_Tl | ESR_LUT | Borosilicate  |       3.087 | True       |               4.158 |               0.7425 |             0.1351  |            836.4  |        0.2184  |
|      39 | s1      |     1600 | NaI_Tl | Ag      | LeadGlass_MCP |       3.052 | True       |               3.465 |               0.8806 |             0.08234 |            172.4  |        0.1653  |

## Pareto front

| core   | coat    | wall          |   t_det_median_ns |   det_yield_per_keV |   objective |   events |
|:-------|:--------|:--------------|------------------:|--------------------:|------------:|---------:|
| LYSO   | ESR_LUT | Borosilicate  |             26.01 |               1.947 |       1.518 |      400 |
| LYSO   | Ag      | LeadGlass_MCP |             27.64 |               3.288 |       3.095 |     1600 |
| LYSO   | Ag      | Borosilicate  |             27.96 |               3.307 |       2.795 |      400 |
| GAGG   | Ag      | LeadGlass_MCP |             61.76 |               6.879 |       5.854 |     4000 |
| GAGG   | Ag      | Borosilicate  |             63.32 |               6.905 |       5.252 |     1600 |
| CsI_Tl | Ag      | LeadGlass_MCP |            841.9  |               8.22  |       7.264 |     4000 |

## Plots

![convergence](plots/convergence.png)
![sensitivity](plots/sensitivity.png)
![pareto](plots/pareto.png)

## Notes

* Screening stages use few events: rankings there are noisy, which is why the best fraction is re-simulated with more statistics and fresh seeds (successive halving).
* Infeasible trials (violated constraints, impossible geometry) are kept in `trials.csv` with the reason in `violations`.
