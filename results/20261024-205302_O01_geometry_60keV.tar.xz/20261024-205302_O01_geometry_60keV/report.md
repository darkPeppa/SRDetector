# O1 - channel geometry and coating for 60 keV imaging (full detector)

Free: channel length L, core diameter D, glass wall thickness and coating. The pitch follows from D + 2 x coating (2 um) + wall, so every candidate is a valid honeycomb. Objective: detected photo-electrons per incident keV (light yield x detection efficiency). Requirements: spatial spread r50 <= 120 um, energy shared with other cells <= 25 %, detection efficiency >= 0.8.

* Base configuration: `full.yaml`, fixed: `{'beam.energy': '60 keV'}`
* Objective: `det_yield_per_keV * detection_efficiency` (maximise)
* Constraints: `psf_r50_um <= 120`, `em_crosstalk <= 0.25`, `detection_efficiency >= 0.8`
* Search: `{'sampler': 'lhs', 'initial': 24, 'events': [300, 900, 2700], 'eta': 3, 'refine': {'iterations': 4, 'events': 2700, 'step': 0.15, 'min_gain': 0.03}, 'final': {'top': 3, 'events': 5000, 'repeats': 3}, 'seed': 1}`
* Simulations: 64, feasible: 39 / 64

## Best configuration

Validated with independent seeds (mean ± std):

* **L** = 1.059128718416902
* **D** = 0.24837909201057393
* **wall** = 0.0033567068231095806
* **coat** = Ag
* objective = 8.092 ± 0.022
* det_yield_per_keV = 9.311 ± 0.027
* detection_efficiency = 0.8691 ± 0.0005
* psf_r50_um = 113.9 ± 0.32
* em_crosstalk = 0.1429 ± 0.0047
* photopeak_fraction = 0.8394 ± 0.0027
* n_cells = 6505 ± 0

Ready-to-run configuration: [`best.yaml`](best.yaml) (`srdet run runs/optimize/20261024-205302_O01_geometry_60keV/best.yaml`)

## Validated candidates

|     L |      D |     wall | coat   |   objective |   objective_std |   det_yield_per_keV |   detection_efficiency |   psf_r50_um |   em_crosstalk |   photopeak_fraction |   n_cells |
|------:|-------:|---------:|:-------|------------:|----------------:|--------------------:|-----------------------:|-------------:|---------------:|---------------------:|----------:|
| 1.059 | 0.2484 | 0.003357 | Ag     |       8.092 |        0.02181  |               9.311 |                 0.8691 |        113.9 |         0.1429 |               0.8394 |      6505 |
| 1.259 | 0.2484 | 0.002    | Ag     |       8.05  |        0.007165 |               9.129 |                 0.8817 |        114.2 |         0.1489 |               0.8646 |      6613 |
| 1.259 | 0.2484 | 0.003357 | Ag     |       7.984 |        0.08233  |               9.143 |                 0.8732 |        114.2 |         0.1491 |               0.8533 |      6505 |

## Top of the last screening stage

|   trial | stage   |   events |     L |      D |     wall | coat   |   objective | feasible   |   det_yield_per_keV |   detection_efficiency |   psf_r50_um |   em_crosstalk |   photopeak_fraction |   n_cells |
|--------:|:--------|---------:|------:|-------:|---------:|:-------|------------:|:-----------|--------------------:|-----------------------:|-------------:|---------------:|---------------------:|----------:|
|      30 | s2      |     2700 | 1.259 | 0.2017 | 0.01191  | Ag     |       7.35  | True       |               8.927 |                 0.8233 |        97.44 |         0.1461 |               0.8615 |      9043 |
|      31 | s2      |     2700 | 1.375 | 0.1322 | 0.009616 | Al     |       2.563 | False      |               3.225 |                 0.7948 |        67.25 |         0.1986 |               0.8133 |     20335 |

## Pareto front

|      L |      D |     wall | coat   |   psf_r50_um |   det_yield_per_keV |   objective |   events |
|-------:|-------:|---------:|:-------|-------------:|--------------------:|------------:|---------:|
| 1.375  | 0.1322 | 0.009616 | Al     |        69.14 |               3.271 |       2.62  |      900 |
| 1.259  | 0.2017 | 0.01191  | Ag     |        97.44 |               8.927 |       7.35  |     2700 |
| 1.259  | 0.2239 | 0.006207 | Ag     |       104.8  |               9.11  |       7.815 |     2700 |
| 1.259  | 0.2484 | 0.01761  | Ag     |       112.1  |               9.139 |       7.352 |     2700 |
| 1.259  | 0.2484 | 0.006207 | Ag     |       112.7  |               9.158 |       7.95  |     2700 |
| 1.059  | 0.2484 | 0.003357 | Ag     |       114.2  |               9.31  |       8.086 |     5000 |
| 1.059  | 0.2484 | 0.006207 | Ag     |       114.2  |               9.351 |       7.924 |     2700 |
| 0.8911 | 0.2484 | 0.006207 | Ag     |       115    |               9.44  |       7.908 |     2700 |

## Plots

![convergence](plots/convergence.png)
![sensitivity](plots/sensitivity.png)
![pareto](plots/pareto.png)

## Notes

* Screening stages use few events: rankings there are noisy, which is why the best fraction is re-simulated with more statistics and fresh seeds (successive halving).
* Infeasible trials (violated constraints, impossible geometry) are kept in `trials.csv` with the reason in `violations`.
