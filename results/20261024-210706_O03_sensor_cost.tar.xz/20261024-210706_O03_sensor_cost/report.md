# O3 - photodetector and its window: signal per cost under a resolution requirement

Ag-coated 2 mm channels. Free: sensor technology and the thickness of the sensor entrance window (light spreads inside a thick window). Objective: photo-electrons per keV per unit relative sensor cost; requirement: spatial spread r50 <= 150 um.

* Base configuration: `full.yaml`, fixed: `{'beam.energy': '60 keV', 'geometry.length': '2 mm', 'optics.coating': 'Ag'}`
* Objective: `det_yield_per_cost` (maximise)
* Constraints: `psf_r50_um <= 150`
* Search: `{'sampler': 'lhs', 'initial': 20, 'events': [400, 1600], 'eta': 3, 'refine': {'iterations': 3, 'events': 1600, 'step': 0.15, 'min_gain': 0.03}, 'final': {'top': 3, 'events': 4000, 'repeats': 3}, 'seed': 3}`
* Simulations: 49, feasible: 27 / 49

## Best configuration

Validated with independent seeds (mean ± std):

* **sensor** = aSi_FPD
* **window** = 0.0
* objective = 8.241 ± 0.031
* det_yield_per_keV = 8.241 ± 0.031
* det_yield_per_cost = 8.241 ± 0.031
* psf_r50_um = 98.56 ± 0.56
* psf_in_cell_fraction = 0.5332 ± 0.0032
* snr_60keV_per_channel = 0.2203 ± 0.00084

Ready-to-run configuration: [`best.yaml`](best.yaml) (`srdet run runs/optimize/20261024-210706_O03_sensor_cost/best.yaml`)

## Validated candidates

| sensor   |    window |   objective |   objective_std |   det_yield_per_keV |   det_yield_per_cost |   psf_r50_um |   psf_in_cell_fraction |   snr_60keV_per_channel |
|:---------|----------:|------------:|----------------:|--------------------:|---------------------:|-------------:|-----------------------:|------------------------:|
| aSi_FPD  | 0         |       8.241 |        0.03125  |               8.241 |                8.241 |        98.56 |                 0.5332 |                  0.2203 |
| aSi_FPD  | 0.0003725 |       8.221 |        0.02173  |               8.221 |                8.221 |        98.58 |                 0.5346 |                  0.2197 |
| CMOS_FSI | 0.0003725 |       2.587 |        0.006134 |               7.762 |                2.587 |        98.89 |                 0.5315 |                 15.54   |

## Top of the last screening stage

|   trial | stage   |   events | sensor    |    window |   objective | feasible   |   det_yield_per_keV |   det_yield_per_cost |   psf_r50_um |   psf_in_cell_fraction |   snr_60keV_per_channel |
|--------:|:--------|---------:|:----------|----------:|------------:|:-----------|--------------------:|---------------------:|-------------:|-----------------------:|------------------------:|
|      20 | s1      |     1600 | sCMOS_BSI | 0.0003725 |       0.489 | True       |               14.67 |                0.489 |         99.5 |                 0.5267 |                    15.6 |

## Pareto front

| sensor   |    window |   psf_r50_um |   det_yield_per_keV |   objective |   events |
|:---------|----------:|-------------:|--------------------:|------------:|---------:|
| EMCCD    | 0.0003725 |        97.13 |               14.83 |      0.2472 |     1600 |

## Plots

![convergence](plots/convergence.png)
![sensitivity](plots/sensitivity.png)
![pareto](plots/pareto.png)

## Notes

* Screening stages use few events: rankings there are noisy, which is why the best fraction is re-simulated with more statistics and fresh seeds (successive halving).
* Infeasible trials (violated constraints, impossible geometry) are kept in `trials.csv` with the reason in `violations`.
